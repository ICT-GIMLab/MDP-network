
import math

MODULE_NAME = "MDP_network"

CHANNEL_NUM = int(32)
ADDR_BIT = int(math.log(CHANNEL_NUM, 2))

DATA_WIDTH = int(32)

FIFO_DEPTH = int(8)